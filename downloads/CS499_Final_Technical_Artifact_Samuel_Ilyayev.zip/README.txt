CS 499 Final Technical Artifact
Samuel Ilyayev

Original_Artifact contains the CS 360 Weight Tracker before the CS 499 enhancements.
Enhanced_Artifact contains the cumulative final version after the software design, algorithms and data structures, and database enhancements.

The enhanced artifact includes layered service/repository design, PBKDF2 password hashing and validation, historical weight analysis with sorting/filtering/moving averages, and a versioned SQLite schema with migration, relational constraints, transactions, indexed queries, and ownership checks.
