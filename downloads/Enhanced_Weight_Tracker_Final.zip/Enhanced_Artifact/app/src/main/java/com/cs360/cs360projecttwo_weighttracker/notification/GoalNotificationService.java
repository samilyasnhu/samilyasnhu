package com.cs360.cs360projecttwo_weighttracker.notification;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import com.cs360.cs360projecttwo_weighttracker.domain.Result;
import com.cs360.cs360projecttwo_weighttracker.session.SessionManager;

import java.util.Locale;

/** Encapsulates goal-notification decisions and SMS delivery away from the Activity. */
public class GoalNotificationService {
    private final Context context;
    private final SessionManager sessionManager;

    public GoalNotificationService(Context context, SessionManager sessionManager) {
        this.context = context.getApplicationContext();
        this.sessionManager = sessionManager;
    }

    public Result<Boolean> notifyIfGoalReached(int userId, double currentWeight, Double goalWeight) {
        if (goalWeight == null || currentWeight > goalWeight) {
            return Result.success(false);
        }

        String phoneNumber = sessionManager.getPhoneNumber(userId);
        boolean permissionGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!sessionManager.isSmsEnabled(userId) || phoneNumber.isEmpty() || !permissionGranted) {
            return Result.failure("Goal reached. SMS notification is not enabled.");
        }

        String message = String.format(
                Locale.US,
                "Congratulations! You reached your goal weight. Current weight: %.1f lbs. Goal: %.1f lbs.",
                currentWeight,
                goalWeight
        );

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
            return Result.success(true);
        } catch (Exception e) {
            return Result.failure("Goal reached, but SMS could not be sent.");
        }
    }
}
