package com.cs360.cs360projecttwo_weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.cs360.cs360projecttwo_weighttracker.domain.WeightRecord;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(AndroidJUnit4.class)
public class DatabaseHelperInstrumentedTest {
    private static final String DATABASE_NAME = "weight_tracker.db";

    private Context context;
    private DatabaseHelper databaseHelper;

    @Before
    public void setUp() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.deleteDatabase(DATABASE_NAME);
        databaseHelper = new DatabaseHelper(context);
    }

    @After
    public void tearDown() {
        if (databaseHelper != null) {
            databaseHelper.close();
        }
        context.deleteDatabase(DATABASE_NAME);
    }

    @Test
    public void rangeQueryReturnsChronologicalRecords() {
        assertTrue(databaseHelper.createUser("samuel", "password1"));
        int userId = databaseHelper.getUserId("samuel", "password1");

        databaseHelper.saveWeightEntryAndGoal(userId, "01/03/2026", 181.0, null);
        databaseHelper.saveWeightEntryAndGoal(userId, "01/01/2026", 183.0, null);
        databaseHelper.saveWeightEntryAndGoal(userId, "01/02/2026", 182.0, null);

        List<WeightRecord> entries = databaseHelper.getWeightEntriesInRange(
                userId,
                "01/01/2026",
                "01/02/2026"
        );

        assertEquals(2, entries.size());
        assertEquals("01/01/2026", entries.get(0).getDate());
        assertEquals("01/02/2026", entries.get(1).getDate());
    }

    @Test
    public void updateAndDeleteRequireEntryOwnership() {
        assertTrue(databaseHelper.createUser("owner", "password1"));
        assertTrue(databaseHelper.createUser("other", "password2"));
        int ownerId = databaseHelper.getUserId("owner", "password1");
        int otherId = databaseHelper.getUserId("other", "password2");

        long entryId = databaseHelper.saveWeightEntryAndGoal(
                ownerId,
                "02/01/2026",
                175.0,
                null
        );

        assertFalse(databaseHelper.updateWeightEntry(
                otherId,
                (int) entryId,
                "02/02/2026",
                174.0
        ));
        assertFalse(databaseHelper.deleteWeightEntry(otherId, (int) entryId));
        assertTrue(databaseHelper.updateWeightEntry(
                ownerId,
                (int) entryId,
                "02/02/2026",
                174.0
        ));
    }

    @Test
    public void constraintsRejectUnknownUserAndInvalidWeight() {
        assertEquals(-1, databaseHelper.saveWeightEntryAndGoal(
                9999,
                "03/01/2026",
                170.0,
                null
        ));

        assertTrue(databaseHelper.createUser("samuel", "password1"));
        int userId = databaseHelper.getUserId("samuel", "password1");
        assertEquals(-1, databaseHelper.saveWeightEntryAndGoal(
                userId,
                "03/01/2026",
                5.0,
                null
        ));
    }

    @Test
    public void weightAndGoalAreSavedTogether() {
        assertTrue(databaseHelper.createUser("samuel", "password1"));
        int userId = databaseHelper.getUserId("samuel", "password1");

        long entryId = databaseHelper.saveWeightEntryAndGoal(
                userId,
                "04/01/2026",
                168.0,
                160.0
        );

        assertTrue(entryId > 0);
        assertNotNull(databaseHelper.getGoalWeight(userId));
        assertEquals(160.0, databaseHelper.getGoalWeight(userId), 0.001);
    }

    @Test
    public void versionOneDatabaseMigratesWithoutDroppingData() {
        databaseHelper.close();
        context.deleteDatabase(DATABASE_NAME);

        SQLiteDatabase legacy = context.openOrCreateDatabase(DATABASE_NAME, 0, null);
        legacy.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL)");
        legacy.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, entry_date TEXT NOT NULL, weight REAL NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id))");
        legacy.execSQL("CREATE TABLE goals (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER UNIQUE NOT NULL, goal_weight REAL NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id))");

        ContentValues user = new ContentValues();
        user.put("id", 1);
        user.put("username", "legacy");
        user.put("password", "legacyPass");
        legacy.insertOrThrow("users", null, user);

        ContentValues weight = new ContentValues();
        weight.put("id", 1);
        weight.put("user_id", 1);
        weight.put("entry_date", "05/15/2026");
        weight.put("weight", 172.0);
        legacy.insertOrThrow("weights", null, weight);

        ContentValues goal = new ContentValues();
        goal.put("user_id", 1);
        goal.put("goal_weight", 165.0);
        legacy.insertOrThrow("goals", null, goal);

        legacy.setVersion(1);
        legacy.close();

        databaseHelper = new DatabaseHelper(context);
        int userId = databaseHelper.getUserId("legacy", "legacyPass");
        List<WeightRecord> entries = databaseHelper.getWeightEntries(userId);

        assertEquals(1, userId);
        assertEquals(1, entries.size());
        assertEquals("05/15/2026", entries.get(0).getDate());
        assertEquals(172.0, entries.get(0).getWeight(), 0.001);
        assertEquals(165.0, databaseHelper.getGoalWeight(userId), 0.001);
    }
}
